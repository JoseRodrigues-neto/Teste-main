-- This file allow to write SQL commands that will be emitted in test and dev.
-- The commands are commented as their support depends of the database
-- insert into myentity (id, field) values(1, 'field-1');
-- insert into myentity (id, field) values(2, 'field-2');
-- insert into myentity (id, field) values(3, 'field-3');
-- alter sequence myentity_seq restart with 4;

-- Exemplo de import.sql com produtos (queijos)

-- Inserir Queijos
INSERT INTO produto (nome, categoria, descricao, preco, peso)
VALUES ('Queijo Minas Frescal', 'azuis', 'Queijo Minas Frescal produzido com leite pasteurizado', 12.50, 500);

INSERT INTO produto (nome, categoria, descricao, preco, peso)
VALUES ('Queijo Prato', 'brancos e frescos', 'Queijo Prato de origem brasileira, ideal para sanduíches', 15.90, 400);

INSERT INTO produto (nome, categoria, descricao, preco, peso)
VALUES ('Queijo Gorgonzola', 'macios e suaves', 'Queijo Gorgonzola italiano, de sabor intenso e cremoso', 22.75, 300);

INSERT INTO produto (nome, categoria, descricao, preco, peso)
VALUES ('Queijo Coalho', 'Queijos de média cura', 'Queijo Coalho típico do Nordeste do Brasil, ideal para grelhados', 9.99, 250);

INSERT INTO produto (nome, categoria, descricao, preco, peso)
VALUES ('QueijoBrie', 'Queijo', 'Queijo Brie francês, macio e cremoso com casca de mofo branco', 18.25, 200);

INSERT INTO produto (nome, categoria, descricao, preco, peso)
VALUES ('Queijo Parmesão', 'Queijo', 'Queijo Parmesão italiano, maturado e de sabor marcante', 29.99, 350);
