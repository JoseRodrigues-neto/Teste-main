package unitins.com.repository;

 

    import java.util.List;
    
    import io.quarkus.hibernate.orm.panache.PanacheRepository;
    import jakarta.enterprise.context.ApplicationScoped;

import unitins.com.model.Queijo;
@ApplicationScoped
public class QueijoRepository  implements PanacheRepository<Queijo> {

    public List<Queijo> findByTipo(String tipo) {
        return find("UPPER(nome) LIKE ?1", "%"+ tipo.toUpperCase() + "%").list();
    }


    public List<Queijo> findByPreco(String preco) {
        return find("UPPER(nome) LIKE ?1", "%"+ preco.toUpperCase() + "%").list();
    }

    public List<Queijo> findByPeso(String peso) {
        return find("UPPER(nome) LIKE ?1", "%"+ peso.toUpperCase() + "%").list();
    }
  
    public List<Queijo> findByDataProducao(String dataProducao) {
        return find("UPPER(nome) LIKE ?1", "%"+ dataProducao.toUpperCase() + "%").list();
    }
    public List<Queijo> findByDataValidade(String dataValidade) {
        return find("UPPER(nome) LIKE ?1", "%"+ dataValidade.toUpperCase() + "%").list();
    }
    public List<Queijo> findByIngredientes(String ingredientes) {
        return find("UPPER(nome) LIKE ?1", "%"+ ingredientes.toUpperCase() + "%").list();
    }
    public List<Queijo> findByProcessoMaturacao(String processoMaturacao) {
        return find("UPPER(nome) LIKE ?1", "%"+ processoMaturacao.toUpperCase() + "%").list();
    }
    
}
