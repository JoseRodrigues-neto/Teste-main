package unitins.com.DTO;

import jakarta.validation.constraints.Size;

public record MaturacaoDTO(
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres")
    String tipo,
     
 
    @Size(min = 2, max = 255, message = "A descrição deve ter entre 2 e 255 caracteres")
    float duracao

) {
} 
    
 
 
