package unitins.com.service;

import java.util.List;

import jakarta.validation.Valid;
import unitins.com.DTO.QueijoDTO;
import unitins.com.DTO.QueijoResponseDTO;

public interface QueijoService {

    public QueijoResponseDTO create(@Valid  QueijoDTO dto);
    public void update(Long id,  QueijoDTO dto);
    public void delete(Long id);
    public QueijoResponseDTO findById(Long id);
    public List<QueijoResponseDTO> findAll();
    public List<QueijoResponseDTO> findByNome(String nome);
    
}
