package unitins.com.DTO;
 
import unitins.com.model.TipoQueijo;
import unitins.com.DTO.TipoQueijoResponseDTO;

public record TipoQueijoResponseDTO (String nome,String quantidade) {
    
    public static TipoQueijoResponseDTO valueOf(TipoQueijo queijo){
        return new  TipoQueijoResponseDTO(
           
        queijo.getNome(),
        queijo.getDescricao());
            
    }
}
