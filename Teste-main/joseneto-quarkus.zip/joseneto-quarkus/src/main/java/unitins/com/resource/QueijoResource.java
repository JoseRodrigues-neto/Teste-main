package unitins.com.resource;

import java.util.List;
import unitins.com.service.QueijoServiceImpl;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import unitins.com.DTO.QueijoDTO;
import unitins.com.DTO.QueijoResponseDTO;

@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/Queijos")
public class QueijoResource {
    
    @Inject
    private QueijoServiceImpl QueijoServiceImpl;

    @GET
    @Path("/{id}")
    public  QueijoResponseDTO findById(@PathParam("id") Long id) {
        return QueijoServiceImpl.findById(id);
    }

    @GET
    public List< QueijoResponseDTO> findAll() {
        return QueijoServiceImpl.findAll();
    }

    @GET
    @Path("/search/nome/{nome}")
    public List< QueijoResponseDTO> findByNome(@PathParam("nome") String nome) {
        return QueijoServiceImpl.findByNome(nome);
    }

 
    @POST
    @Transactional
    public  QueijoResponseDTO create( QueijoDTO dto) {
        return QueijoServiceImpl.create(dto);
    }

    @PUT
    @Transactional
    @Path("/{id}")
    public void update(@PathParam("id") Long id,  QueijoDTO dto) {
        QueijoServiceImpl.update(id, dto);
    }

    @DELETE
    @Transactional
    @Path("/{id}")
    public void delete(@PathParam("id") Long id) {
        QueijoServiceImpl.delete(id);
    }
}
