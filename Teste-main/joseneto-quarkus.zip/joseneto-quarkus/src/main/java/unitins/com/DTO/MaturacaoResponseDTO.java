package unitins.com.DTO;

import unitins.com.model.Maturacao;

public record MaturacaoResponseDTO(
    String tipo, float quantiade
) {
    public static MaturacaoResponseDTO  valueOf(Maturacao maturacao){
        return new  MaturacaoResponseDTO(
           
        maturacao.getTipo(),
        maturacao.getDuracao());
            
    }
}  