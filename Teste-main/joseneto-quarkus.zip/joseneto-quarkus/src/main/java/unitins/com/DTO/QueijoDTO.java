package unitins.com.DTO;

import javax.xml.crypto.Data;
import unitins.com.model.Ingrediente;
import unitins.com.model.Maturacao;
import unitins.com.model.TipoQueijo;

public record QueijoDTO( 
    
    TipoQueijo tipo,
    double preco,
    double peso,
    Data dataProducao,
    Data dataValidade,
    Ingrediente ingredientes,
    Maturacao processoMaturacao
)
    {}

