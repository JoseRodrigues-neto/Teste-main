package unitins.com.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record FornecedorDTO ( 
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres")
    String nome,
    @NotBlank(message = "O cnpj não pode ser nula ou vazia")
    @Size(min = 11, max = 14, message = "O cnjp tem que ter 14 numeros")
    String cnpj,
     
    @Size(min = 4, max = 30, message = "Endereco não pode ter mais de 30 caracteres")
    String endereco,

    @Size(min = 4, max = 30, message = "Precisa ter entre 4 a 25 caracteres")
    String email,

    @Size(min = 8, max = 14, message = "Tem que ter entre 8 e 14 numeros")
    int contato){
    
}
