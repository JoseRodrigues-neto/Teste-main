package unitins.com.model;


import jakarta.persistence.Column;
 

public class Ingrediente {

    @Column(length = 10, nullable = false)
    private String nome;

    
    @Column(length = 10, nullable = false)
    private float quantidade;


    public String getNome() {
        return nome;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }


    public float getQuantidade() {
        return quantidade;
    }


    public void setQuantidade(float quantidade) {
        this.quantidade = quantidade;
    }
    
    
}
