package unitins.com.service;


import java.util.List;


import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import unitins.com.DTO.FornecedorDTO;
import unitins.com.DTO.FornecedorResponseDTO;
import unitins.com.model.Fornecedor;
import jakarta.enterprise.context.ApplicationScoped;
import unitins.com.repository.FornecedorRepository;

@ApplicationScoped 
public class FornecedorServiceImpl implements FornecedorService {
   
     @Inject
    public FornecedorRepository FornecedorRepository;


    @Override
    @Transactional
    public FornecedorResponseDTO create(@Valid FornecedorDTO dto) {


        Fornecedor Fornecedor = new Fornecedor();
        Fornecedor.setNome(dto.nome());
        Fornecedor.setCnpj(dto.cnpj());;
        Fornecedor.setEndereco(dto.endereco());;
        Fornecedor.setEmail(dto.email());
        Fornecedor.setContato(dto.contato());


        FornecedorRepository.persist(Fornecedor);
        return FornecedorResponseDTO.valueOf(Fornecedor);
    }


    @Override
    @Transactional
    public void update(Long id, FornecedorDTO dto) {
        Fornecedor FornecedorBanco = FornecedorRepository.findById(id);


        FornecedorBanco.setNome(dto.nome());
        FornecedorBanco.setCnpj(dto.cnpj());;
        FornecedorBanco.setEndereco(dto.endereco());;
        FornecedorBanco.setEmail(dto.email());
        FornecedorBanco.setContato(dto.contato());
    }


    @Override
    @Transactional
    public void delete(Long id) {
        FornecedorRepository.deleteById(id);
    }


    @Override
    public FornecedorResponseDTO findById(Long id) {
        return FornecedorResponseDTO.valueOf(FornecedorRepository.findById(id));
    }


    @Override
    public List<FornecedorResponseDTO> findAll() {
        return FornecedorRepository
                .listAll()
                .stream()
                .map(e -> FornecedorResponseDTO.valueOf(e))
                .toList();
    }


    @Override
    public List<FornecedorResponseDTO> findByNome(String nome) {
        return FornecedorRepository.findByNome(nome)
                .stream()
                .map(e -> FornecedorResponseDTO.valueOf(e))
                .toList();
    }


}


