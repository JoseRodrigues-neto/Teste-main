package unitins.com.model;
    
import com.fasterxml.jackson.annotation.JsonFormat;
@JsonFormat(shape = JsonFormat.Shape.OBJECT)
public enum OrigemLeite {
    
    VACA(1, "vaca"),
    CABRA(2, "cabra");

    private int id;
    private String nome;

    OrigemLeite(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public static OrigemLeite valueOf(Integer id) throws IllegalArgumentException {
        for (OrigemLeite origemLeite : OrigemLeite.values()) {
            if (origemLeite.id == id)
                return origemLeite;
        }
        throw new IllegalArgumentException("id inválido.");
    }

}
 
