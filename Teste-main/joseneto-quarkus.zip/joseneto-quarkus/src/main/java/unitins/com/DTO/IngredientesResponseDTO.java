package unitins.com.DTO;

import unitins.com.model.Ingrediente;

public record IngredientesResponseDTO(String nome, float quantidade) {

    public static IngredientesResponseDTO  valueOf(Ingrediente igrediente){
        return new  IngredientesResponseDTO(
           
        igrediente.getNome(),
        igrediente.getQuantidade());
            
    }
}

