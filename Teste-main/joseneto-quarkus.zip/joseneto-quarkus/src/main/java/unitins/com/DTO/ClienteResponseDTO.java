package unitins.com.DTO;

import unitins.com.model.Cliente;

public record ClienteResponseDTO (
    Long id,
    String nome,
    String cpf,
    String dataNacimento,
    String email,
    int contato){
        public static ClienteResponseDTO valueOf(Cliente cliente) {
            return new ClienteResponseDTO(
                cliente.getId(), 
                cliente.getNome(), 
                cliente.getCpf(),
                cliente.getDataNacimento(),
                cliente.getEmail(),
                cliente.getContato());
        }
        
    }


