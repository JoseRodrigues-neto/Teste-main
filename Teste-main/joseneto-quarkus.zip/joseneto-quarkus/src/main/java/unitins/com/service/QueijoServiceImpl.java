package unitins.com.service;

import java.util.List;

import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import unitins.com.DTO.QueijoDTO;
import jakarta.enterprise.context.ApplicationScoped;
import unitins.com.DTO.QueijoResponseDTO;
import unitins.com.model.Queijo;
import unitins.com.repository.QueijoRepository;

@ApplicationScoped
public class QueijoServiceImpl implements QueijoService  {
    
    @Inject
    private QueijoRepository queijoRepository;

    public QueijoResponseDTO findById(Long id) {
        return  QueijoResponseDTO.valueOf(queijoRepository.findById(id));
    }

    public List <QueijoResponseDTO> findAll() {
        return queijoRepository
            .listAll()
            .stream()
            .map(e ->  QueijoResponseDTO.valueOf(e))
            .toList();
    }

    public List< QueijoResponseDTO> findByTipo(String tipo) {
        return queijoRepository.findByTipo(tipo)
            .stream()
            .map(e ->  QueijoResponseDTO.valueOf(e))
            .toList();
    }
 
    @Transactional
    public  QueijoResponseDTO create(QueijoDTO dto) {
        Queijo queijo = new Queijo();
        queijo.getTipo(dto.tipo());
        queijo.setCategoria(dto.dataValidade());
        queijo.setDescricao(dto.descricao());
         

        queijoRepository.persist(queijo);
        return  QueijoResponseDTO.valueOf(queijo);
    }

    @Transactional
    public void update(Long id,  QueijoDTO dto) {
        Queijo queijo = queijoRepository.findById(id);
        if (queijo != null) {
            queijo.setNome(dto.nome());
            queijo.setCategoria(dto.categoria());
            queijo.setDescricao(dto.descricao());
            queijo.setPreco(dto.preco());
            queijo.setPeso(dto.peso());
        }
    }

    @Transactional
    public void delete(Long id) {
        queijoRepository.deleteById(id);
    }
}
