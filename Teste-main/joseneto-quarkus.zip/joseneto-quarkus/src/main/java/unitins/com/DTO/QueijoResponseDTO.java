package unitins.com.DTO;

import javax.xml.crypto.Data;
import unitins.com.model.Ingrediente;
import unitins.com.model.Maturacao;
import unitins.com.model.Queijo;
import unitins.com.model.TipoQueijo;

public record QueijoResponseDTO(
    TipoQueijo tipo,
    double preco,
    double peso,
    Data dataProducao,
    Data dataValidade,
    Ingrediente ingredientes,
    Maturacao processoMaturacao
) {
    
    public static QueijoResponseDTO valueOf(Queijo queijo){
        return new  QueijoResponseDTO(
        
        queijo.getTipo(),
        queijo.getPreco(),
        queijo.getPeso(),
        queijo.getDataProducao(),
        queijo.getDataValidade(),
        queijo.getIngredientes(),
        queijo.getProcessoMaturacao()
        );
            
    }
}
