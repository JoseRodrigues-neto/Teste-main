package unitins.com.model;


import javax.xml.crypto.Data;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class Queijo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
 
    @Column(length = 10, nullable = false)
    private TipoQueijo tipo;

    @Column(length = 10, nullable = false)
    private double preco;

    @Column(length = 5, nullable = false)
    private double peso;

    @Column(length = 5, nullable = false)
    private Data dataProducao;

    @Column(length = 5, nullable = false)
    private Data dataValidade;

    @Column(length = 5, nullable = false)
    private Ingrediente ingredientes;

    @Column(length = 5, nullable = false)
    private Maturacao processoMaturacao;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public Data getDataProducao() {
        return dataProducao;
    }

    public void setDataProducao(Data dataProducao) {
        this.dataProducao = dataProducao;
    }

    public Data getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(Data dataValidade) {
        this.dataValidade = dataValidade;
    }

    public Ingrediente getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(Ingrediente ingredientes) {
        this.ingredientes = ingredientes;
    }

    public Maturacao getProcessoMaturacao() {
        return processoMaturacao;
    }

    public void setProcessoMaturacao(Maturacao processoMaturacao) {
        this.processoMaturacao = processoMaturacao;
    }

    public TipoQueijo getTipo() {
        return tipo;
    }

    public void setTipo(TipoQueijo tipo) {
        this.tipo = tipo;
    }
    
    
}