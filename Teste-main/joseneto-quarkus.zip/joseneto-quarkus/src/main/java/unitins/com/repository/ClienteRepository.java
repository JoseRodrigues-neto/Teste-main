package unitins.com.repository;

import java.util.List;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
import unitins.com.model.Cliente;
 

@ApplicationScoped
public class ClienteRepository implements PanacheRepository<Cliente>  {
    
        public List<Cliente> findByNome(String nome) {
        return find("UPPER(nome) LIKE ?1", "%"+ nome.toUpperCase() + "%").list();
    }

    public List<Cliente> findByCategoria(String cpf) {
        return find("UPPER(nome) LIKE ?1", "%"+ cpf.toUpperCase() + "%").list();
    }
    public List<Cliente> findByDescricao(String dataNacimento) {
        return find("UPPER(nome) LIKE ?1", "%"+ dataNacimento.toUpperCase() + "%").list();
    }
    public List<Cliente> findByPreco(String email) {
        return find("UPPER(nome) LIKE ?1", "%"+ email.toUpperCase() + "%").list();
    }
    public List<Cliente> findByPeso(String contato) {
        return find("UPPER(nome) LIKE ?1", "%"+ contato.toUpperCase() + "%").list();
    }
}
