package unitins.com.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
 
@Entity
public class Maturacao {

    @Column(length = 10, nullable = false)
    private String tipo;

    
    @Column(length = 10, nullable = false)
    private float duracao;


    public String getTipo() {
        return tipo;
    }


    public void setTipo(String tipo) {
        this.tipo = tipo;
    }


    public float getDuracao() {
        return duracao;
    }


    public void setDuracao(float duracao) {
        this.duracao = duracao;
    }


     
}
