package unitins.com.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record ClienteDTO (    @NotBlank(message = "O nome não pode ser nulo ou vazio")
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres")
    String nome,
    @NotBlank(message = "O CPF não pode ser nula ou vazia")
    @Size(min = 11, max = 50, message = "O CPF tem que ter 11 numeros")
    String cpf,
     
    @Size(min = 4, max = 25, message = "Data pode ser escrita")
    String dataNacimento,

    @Size(min = 4, max = 25, message = "Precisa ter entre 4 a 25 caracteres")
    String email,

    @Size(min = 8, max = 14, message = "Tem que ter entre 8 e 14 numeros")
    int contato
      ) { }
