package unitins.com.DTO;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record IngredientesDTO(
    @NotBlank(message = "O nome não pode ser nulo ou vazio")
    @Size(min = 2, max = 100, message = "O nome deve ter entre 2 e 100 caracteres")
    String nome,
     
    @NotBlank(message = "A descrição não pode ser nula ou vazia")
    @Size(min = 2, max = 255, message = "A descrição deve ter entre 2 e 255 caracteres")
    float quantidade
    

) {
}  