package unitins.com.model;

public class Funconario {
    
}
