package unitins.com.repository;

import java.util.List;

import io.quarkus.hibernate.orm.panache.PanacheRepository;
import jakarta.enterprise.context.ApplicationScoped;
 
import unitins.com.model.Fornecedor;

@ApplicationScoped
public class FornecedorRepository implements PanacheRepository<Fornecedor>{
    
    public List<Fornecedor> findByNome(String nome) {
        return find("UPPER(nome) LIKE ?1", "%"+ nome.toUpperCase() + "%").list();
    }

    public List<Fornecedor> findByCategoria(String cnpj) {
        return find("UPPER(nome) LIKE ?1", "%"+ cnpj.toUpperCase() + "%").list();
    }
    public List<Fornecedor> findByDescricao(String endereco) {
        return find("UPPER(nome) LIKE ?1", "%"+ endereco.toUpperCase() + "%").list();
    }
    public List<Fornecedor> findByPreco(String email) {
        return find("UPPER(nome) LIKE ?1", "%"+ email.toUpperCase() + "%").list();
    }
    public List<Fornecedor> findByPeso(String contato) {
        return find("UPPER(nome) LIKE ?1", "%"+ contato.toUpperCase() + "%").list();
    }
}
