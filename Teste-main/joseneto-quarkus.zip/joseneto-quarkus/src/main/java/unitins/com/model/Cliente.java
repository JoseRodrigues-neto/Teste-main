package unitins.com.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(length = 60, nullable = false)
    private String nome;

    @Column(length = 11, nullable = false)
    private String cpf;

    @Column(length = 25, nullable = false)
    private String dataNacimento;

    @Column(length = 30, nullable = false)
    private String email;

    @Column(length = 10, nullable = false)
    private int contato;

    public String getNome() {
        return nome;
    }
    public String getCpf() {
        return cpf;
    }
    public String getDataNacimento() {
        return dataNacimento;
    }
    public String getEmail() {
        return email;
    }
    public int getContato() {
        return contato;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void setDataNacimento(String dataNacimento) {
        this.dataNacimento = dataNacimento;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setContato(int contato) {
        this.contato = contato;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    
}
