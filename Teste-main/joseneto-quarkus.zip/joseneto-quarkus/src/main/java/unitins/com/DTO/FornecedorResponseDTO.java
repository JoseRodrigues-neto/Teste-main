package unitins.com.DTO;

import unitins.com.model.Fornecedor;

public record FornecedorResponseDTO(
    Long id,
    String nome,
    String cnpj,
    String endereco,
    String email,
    int contato
) {

     public static FornecedorResponseDTO valueOf(Fornecedor fornecedor) {
            return new FornecedorResponseDTO(
               fornecedor.getId(), 
               fornecedor.getNome(), 
               fornecedor.getCnpj(),
               fornecedor.getEndereco(),
               fornecedor.getEmail(),
               fornecedor.getContato());
        }
}  