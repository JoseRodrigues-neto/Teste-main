package unitins.com.service;


import java.util.List;


import jakarta.validation.Valid;
import unitins.com.DTO.FornecedorDTO;
import unitins.com.DTO.FornecedorResponseDTO;


public interface FornecedorService {
   
    public FornecedorResponseDTO create(@Valid FornecedorDTO dto);
    public void update(Long id, FornecedorDTO dto);
    public void delete(Long id);
    public FornecedorResponseDTO findById(Long id);
    public List<FornecedorResponseDTO> findAll();
    public List<FornecedorResponseDTO> findByNome(String nome);
   
}
